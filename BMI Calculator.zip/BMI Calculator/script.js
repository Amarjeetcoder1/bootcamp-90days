// Simple BMI Calculator 

let weight = 65; // in Kilogramms
let height = 1.75; //in meters

let bmi = weight / (height * height);

console.log("Your BMI is: " + bmi);
