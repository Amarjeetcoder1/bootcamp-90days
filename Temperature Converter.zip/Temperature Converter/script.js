//Temperature Convert: Celsius to Fahrenheit

let celsius = 45;
let fahrenheit = (celsius * 9 / 5) + 32;

console.log(celsius + "°C is equal to " + fahrenheit + "°F");

// Reassign the value 
celsius = 100;
fahrenheit = (celsius * 9 / 5) + 32;

console.log(celsius + "°C is equal to " + fahrenheit + "°F");


